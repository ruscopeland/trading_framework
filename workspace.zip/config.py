# config/config.py

# Kraken API Configuration
KRAKEN_API_KEY = "VClK2axNzPEPv3R6526MH5U+pC1ieOzcVUgpQqhgxo1AZzZ8kZkirNg/"
KRAKEN_API_SECRET = "FALK/vwp/lJeyEcTK7Vke+mNeUh0XfAvwelcBp0C30wPxWtiXAzL/CSriaTIlH357Y4/cOykrI1K7RjFIl4JDA=="

# Trading Pairs Configuration
TRADING_PAIRS = [
    "XBT/USD",
    "ETH/USD",
    # Add more pairs as needed
]

# System Configuration
GUI_UPDATE_INTERVAL = 0.1  # seconds
DATA_UPDATE_INTERVAL = 1.0  # seconds
HISTORY_SAVE_INTERVAL = 3600  # seconds

# Risk Management Configuration
MAX_POSITION_SIZE = {
    "XBT/USD": 1.0,
    "ETH/USD": 10.0,
    # Add more pairs as needed
}

MAX_ORDER_SIZE = {
    "XBT/USD": 0.5,
    "ETH/USD": 5.0,
    # Add more pairs as needed
}

# Strategy Configuration
STRATEGY_PARAMS = {
    "MovingAverageCross": {
        "fast_ma": 10,
        "slow_ma": 20,
        "min_volume": 1.0,
        "entry_threshold": 0.001,
        "exit_threshold": 0.0005
    }
    # Add more strategy configurations as needed
}
