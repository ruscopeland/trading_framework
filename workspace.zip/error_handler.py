# core/error_handler.py
